Updated FC package is in fc.pdf
The pdf is also split into multiple sections for grader's convenience in files of format fc (<part #>).pdf
Alternatively, fc.pdf has a table of contents page with clickable links.

Prototypes included in Prototype folder.
Open the index.html file in any web browser to view the live prototype.

All other data in the included .ppt